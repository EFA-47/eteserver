#include "loadBalancer.h"
#include "loadBalancerClient.h"
#include "jsonfile.h"
#include <unistd.h>
#include <json/json.h>
#include <cstdlib>
#include <iostream>
#include <thread>

std::string path = "/home/em/Desktop/loadBalancer-cpp/middleman.json";

int main() {
  
    loadBalancer loadBalancer1(1024); // Create a server on port 12345
    std::thread t1 = std::thread([&]() {loadBalancer1.startListening();});
    t1.detach();
    
    sleep(10);
    std::string jsonString= getJsonContent(path);
    //change the string to json data
    Json::Value json_object= getJsonObject(jsonString);
    jsonString = getJsonValue(json_object);


    loadBalancer loadBalancer3(1028);
    std::thread t3 = std::thread([&]() {loadBalancer3.startListening();});
    t3.detach();
    
    std::cout << "now\n";
    sleep(10);
    jsonString= getJsonContent(path);
    json_object= getJsonObject(jsonString);
    jsonString = getJsonValue(json_object);

    loadBalancerClient myClient1("127.0.0.1", 1026); // Connect to the server on localhost:22
    myClient1.sendMessage(jsonString);

    loadBalancerClient myClient2("127.0.0.1", 1027); // Connect to the server on localhost:22
    myClient2.sendMessage(jsonString);

    return 0;
}
