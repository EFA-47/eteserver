#ifndef loadBalancer_H
#define loadBalancer_H

class loadBalancer {
public:
    loadBalancer(int port);
    void startListening();

private:
    int loadBalancerSocket;
    int port;
};

#endif // loadBalancer_H