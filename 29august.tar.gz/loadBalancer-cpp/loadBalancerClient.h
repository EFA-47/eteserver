#include <string>
#ifndef LOADBALANCERCLIENT_H
#define LOADBALANCERCLIENT_H



class loadBalancerClient {
public:
    loadBalancerClient(const std::string& serverIP, int serverPort);
    void sendMessage(const std::string& message);

private:
    int clientSocket;
    std::string serverIP;
    int serverPort;
};

#endif // CLIENT_H