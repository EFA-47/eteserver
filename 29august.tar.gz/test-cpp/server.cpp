#include "server.h"
#include <iostream>
#include <cstring>
#include <arpa/inet.h>
#include <unistd.h>
#include <json/json.h>
#include <fstream>
#include "serverClient.h"

Server::Server(int port) : port(port){
    serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket == -1) {
        std::cerr << "Error creating socket" << std::endl;
        // Handle error
    }
    struct sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(port);
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    printf("server socket: %d\n",serverSocket);
    if (bind(serverSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == -1) {
        std::cerr << "Error binding" << std::endl;
        // Handle error
    }
}

void Server::startListening() {
    if (listen(serverSocket, 5) == -1) {
        std::cerr << "Error listening" << std::endl;
        // Handle error
    }

    std::cout << "Server listening on port " << port << "..." << std::endl;

    while (true) {
        struct sockaddr_in clientAddr;
        socklen_t clientAddrSize = sizeof(clientAddr);
        int clientSocket = accept(serverSocket, (struct sockaddr*)&clientAddr, &clientAddrSize);
        if (clientSocket == -1) {
            std::cerr << "Error accepting connection" << std::endl;
            // Handle error
            continue;
        }
        
        // Read data from client
        char buffer[256];
        memset(buffer, 0, sizeof(buffer));
        
        int bytesRead = recv(clientSocket, buffer, sizeof(buffer), 0);



    Json::Value json_object;
    Json::CharReaderBuilder reader;
    std::istringstream iss(buffer);
    std::string errs;

    // Parse the JSON string into a JSON object
    Json::parseFromStream(reader, iss, &json_object, &errs);

    //json_object["message"] = json_object["message"].asString() + "123";
    
    std::ofstream outFile("storage.json");  // Open the file for writing

    
    outFile << json_object;  // Write the modified JSON object to the file
    outFile.close();  // Close the file
    










        if (bytesRead <= 0) {
            std::cerr << "Error reading data" << std::endl;
            // Handle error
        } else {
            // std::cout << "Received data from client: " << buffer << std::endl;
            std::cout << "mesasge: " << json_object["message"].asString() << std::endl;
        }
        
        close(clientSocket);
    }

    close(serverSocket);
}
