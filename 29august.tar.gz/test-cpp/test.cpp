#include "server.h"
#include <unistd.h>
#include <json/json.h>
#include <string>
#include "serverClient.h"
#include "jsonfile.h"
#include <thread>

std::string path = "/home/em/Desktop/test-cpp/storage.json";
int main() {
  std::string jsonString= getJsonContent(path);

  //change the string to json data
  Json::Value json_object= getJsonObject(jsonString);

  jsonString = getJsonValue(json_object, "id");
  int id =1;
  serverClient myclient("127.0.0.1", 1024, jsonString); // Connect to the server on localhost:22
  myclient.sendMessage(jsonString);


  Server server(1026); // Create a server on port 12345

  std::thread t = std::thread([&]() {server.startListening();});
  t.detach();
  sleep(10);
  jsonString= getJsonContent(path);
  json_object= getJsonObject(jsonString);
  jsonString = getJsonValue(json_object, "id");

  sleep(10);
  jsonString= getJsonContent(path);
  json_object= getJsonObject(jsonString);
  jsonString = getJsonValue(json_object, "id");

  return 0;
}
