#include "loadBalancer.h"
#include "loadBalancerClient.h"
#include "jsonfile.h"
#include <unistd.h>
#include <json/json.h>
#include <cstdlib>
#include <iostream>
#include <thread>
#include <queue>

std::string path = "/home/em/Desktop/loadBalancer-cpp/middleman.json";

int main() {
    std::string jsonString;
    Json::Value json_object;

    //std::queue<int> clientQueue;
    //int serverList[2];
    
    
    loadBalancer loadBalancer1(1024); // Create a server on port 12345 from servers
    std::thread t1 = std::thread([&]() {loadBalancer1.startListening();});
    t1.detach();
    
    sleep(10);
    jsonString = handleJsonPart(path);

    loadBalancer loadBalancer3(1028); //listens from client
    std::thread t3 = std::thread([&]() {loadBalancer3.startListening();});
    t3.detach();
    
    std::cout << "now\n";
    sleep(10);
    jsonString= handleJsonPart(path);

    //loadBalancerClient myClient1("127.0.0.1", 1026); // server 1
    //myClient1.sendMessage(jsonString); 
    

    return 0;
}
