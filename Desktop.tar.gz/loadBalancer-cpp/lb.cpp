#include "loadBalancer.h"
#include <iostream>
#include <cstring>
#include <arpa/inet.h>
#include <unistd.h>
#include <json/json.h>
#include <fstream>
#include <queue>
#include "loadBalancerClient.h"
#include "jsonfile.h"

std::vector<loadBalancerClient> serverList;

loadBalancer::loadBalancer(int port) : port(port) {
    loadBalancerSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (loadBalancerSocket == -1) {
        std::cerr << "Error creating socket" << std::endl;
        // Handle error
    }
    serverCount = 0;
    

    struct sockaddr_in loadBalancerAddr;
    loadBalancerAddr.sin_family = AF_INET;
    loadBalancerAddr.sin_port = htons(port);
    loadBalancerAddr.sin_addr.s_addr = INADDR_ANY;
    printf("loadBalancer socket: %d\n",loadBalancerSocket);
    if (bind(loadBalancerSocket, (struct sockaddr*)&loadBalancerAddr, sizeof(loadBalancerAddr)) == -1) {
        std::cerr << "Error binding" << std::endl;
        // Handle error
    }
}


void loadBalancer::startListening() {
    if (listen(loadBalancerSocket, 5) == -1) {
        std::cerr << "Error listening" << std::endl;
        // Handle error
    }
    
    
    std::cout << "loadBalancer listening on port " << port << "..." << std::endl;

    while (true) {
        struct sockaddr_in clientAddr;
        socklen_t clientAddrSize = sizeof(clientAddr);
        int clientSocket = accept(loadBalancerSocket, (struct sockaddr*)&clientAddr, &clientAddrSize);
        if (clientSocket == -1) {
            std::cerr << "Error accepting connection" << std::endl;
            // Handle error
            continue;
        }
        
        // Read data from client
        char buffer[256];
        memset(buffer, 0, sizeof(buffer));
        
        int bytesRead = recv(clientSocket, buffer, sizeof(buffer), 0);



    Json::Value json_object;
    Json::CharReaderBuilder reader;
    std::istringstream iss(buffer);
    std::string errs;

    // Parse the JSON string into a JSON object
    Json::parseFromStream(reader, iss, &json_object, &errs);

    //json_object["message"] = json_object["message"].asString();
 
    //std::ofstream outFile("middleman.json");  // Open the file for writing

    
    //outFile << json_object;  // Write the modified JSON object to the file
    //outFile.close();  // Close the file
    
        if (bytesRead <= 0) {
            std::cerr << "Error reading data" << std::endl;
            // Handle error
        } else {
            // std::cout << "Received data from client: " << buffer << std::endl;
            int type = stoi(json_object["type"].asString());
            std::cout << "type: " << type << std::endl;
            std::string ip;
            int id;
            int port;
            int ram;


            if(type ==1){
                int minram = 100;
                int bestServer=0;
                
                for(int i =0; i< serverList.size(); i++){
                    if (serverList[i].serverRam < minram){
                        minram = serverList[i].serverRam;
                        bestServer = i;
                    }
                }

                id = serverList[bestServer].serverID;
                ip = serverList[bestServer].serverIP;
                port = serverList[bestServer].serverPort;
                ram = serverList[bestServer].serverRam;
                std::cout << "id ip port ram: " << id << " " << ip << " " << port << " " << ram << std::endl;


                if(minram<100){
                    loadBalancerClient myclient(serverList[bestServer].serverIP,serverList[bestServer].serverPort);
                    //loadBalancerClient myclient1(ip,port);
                    std::string jsonString = getJsonValue(json_object);
                    myclient.sendMessage(json_object["message"].asString());
                    std::cout << "message: " << json_object["message"].asString() << std::endl;

                }
                

            }else if(type == 2){
                
                id = stoi(json_object["id"].asString());
                ip = (json_object["ip"].asString());
                port = stoi(json_object["port"].asString());
                ram = stoi(json_object["ram"].asString());
                std::cout << "id ip port ram: " << id << " " << ip << " " << port << " " << ram << std::endl;

                loadBalancerClient myclient(ip, port);
                

                myclient.serverID = id;
                myclient.serverIP = ip;
                myclient.serverPort = port;
                myclient.serverRam = ram;
                
                
                serverList.push_back(myclient);
                serverCount++;
                std::cout << "server count: " << serverCount << std::endl;
               
            }else if(type == 3){

                id = json_object["id"].asInt();
                ram = json_object["ram"].asInt();

                for(int i=0; i<sizeof(serverList);i++){
                    if(serverList[i].serverID == id){
                        serverList[i].serverRam = ram;
                    }
                }

            }else{
                std::cout << "wrong type\n";
            }


            // Json::Value ramValue = json_object["ram"];
            // std::string ram = ramValue.asString();
            // serverList[0]=stoi(ram);
        }
        
        close(clientSocket);
    }

    

    close(loadBalancerSocket);
}

