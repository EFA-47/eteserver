#include <string>
#ifndef LOADBALANCERCLIENT_H
#define LOADBALANCERCLIENT_H



class loadBalancerClient {
public:
    loadBalancerClient(const std::string& serverIP, int serverPort);
    void sendMessage(const std::string& message);
    int serverID;
    std::string serverIP;
    int serverPort;
    int serverRam;
    
private:
    int clientSocket;
    
};

#endif // CLIENT_H