#ifndef loadBalancer_H
#define loadBalancer_H
#include <list>


class loadBalancer {
public:
    loadBalancer(int port);
    void startListening();
    //loadBalancerClient serverList[5];

private:
    int loadBalancerSocket;
    int port;
    //loadBalancerClient serverList[20];
    int serverCount;
};

#endif // loadBalancer_H