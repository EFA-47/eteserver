#include <thread>
#include <string>
#include <vector>
#ifndef CLIENT_H
#define CLIENT_H

void sendMessagee(std::string abc);
void createThreads(std::string jsonString, int threadCount);

class Client {
public:
    Client(const std::string& serverIP, int serverPort);
    void sendMessage(const std::string& message);

private:
    int clientSocket;
    std::string serverIP;
    int serverPort;
};

#endif // CLIENT_H