#include "client.h"
#include "jsonfile.h"


const int threadCount = 14;
std::string path = "/home/em/Desktop/test2-cpp/message.json";

int main() {

std::string jsonString= getJsonContent(path);

//change the string to json data
Json::Value json_object= getJsonObject(jsonString);

jsonString = getJsonValue(json_object);

//create 14 threads to use sendMessage function
createThreads(jsonString, threadCount);

return 0;    
}