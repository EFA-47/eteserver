#include "client.h"
#include <iostream>
#include <cstring>
#include <arpa/inet.h>
#include <unistd.h>

Client::Client(const std::string& serverIP, int serverPort) : serverIP(serverIP), serverPort(serverPort) {
    clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (clientSocket == -1) {
        std::cerr << "Error creating socket" << std::endl;
        // Handle error
    }

    struct sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(serverPort);
    inet_pton(AF_INET, serverIP.c_str(), &serverAddr.sin_addr);

    if (connect(clientSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == -1) {
        std::cerr << "Error connecting" << std::endl;
        // Handle error
    }
}

void Client::sendMessage(const std::string& message) {
    send(clientSocket, message.c_str(), message.size(), 0);
    // ...
    close(clientSocket);
}

void sendMessagee(std::string abc){
    Client client("127.0.0.1", 1028); // Connect to the server on localhost:22
    client.sendMessage(abc);
    
}

void createThreads(std::string jsonString, int threadCount){

    std::vector<std::thread> myThreads(threadCount);
for (int i = 0; i < threadCount; i++)
{
    myThreads[i] = std::thread([&]() {sendMessagee(jsonString); });
    myThreads[i].join();
}

}
