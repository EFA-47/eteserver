#ifndef SERVER_H
#define SERVER_H

class Server {
public:
    Server(int port);
    void startListening();

private:
    int serverSocket;
    int port;
    int ram;
};

#endif // SERVER_H
