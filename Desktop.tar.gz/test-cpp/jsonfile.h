#include <json/json.h>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>

std::string getJsonContent(std::string path);
Json::Value getJsonObject(std::string jsonString);
std::string getJsonValue(Json::Value json_object, std::string abc);