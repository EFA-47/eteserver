#include "server.h"
#include <unistd.h>
#include <json/json.h>
#include "client.h"


int main() {
    // Create and start the server

    //     if(pid>0){
    // Server server(1024); // Create a server on port 12345
    //     server.startListening();
    //     }

    //     // Create a client and send a message
    //     else{
     //Client client("127.0.0.1", 1024); // Connect to the server on localhost:22
       //  client.sendMessage("Hello, server!");
    //     }

    Server server(1024); // Create a server on port 12345
    server.startListening();

    return 0;
}
