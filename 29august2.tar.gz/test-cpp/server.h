#ifndef SERVER_H
#define SERVER_H

class Server {
public:
    Server(int port);
    void startListening();

private:
    int serverSocket;
    int port;
};

#endif // SERVER_H
