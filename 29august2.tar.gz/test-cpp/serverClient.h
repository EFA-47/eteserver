#include <string>
#ifndef SERVERCLIENT_H
#define SERVERCLIENT_H



class serverClient {
public:
    serverClient(const std::string& serverIP, int serverPort, std::string& serverid);
    void sendMessage(const std::string& message);
    void setID(std::string& id);
    std::string getID();

private:
    int clientSocket;
    std::string serverIP;
    int serverPort;
    std::string serverid;
};

#endif // CLIENT_H