#include "serverClient.h"
#include <iostream>
#include <cstring>
#include <arpa/inet.h>
#include <unistd.h>

std::string serverID = "1";
serverClient::serverClient(const std::string& serverIP, int serverPort, std::string& serverid) : serverIP(serverIP), serverPort(serverPort), serverid(serverid) {
    clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (clientSocket == -1) {
        std::cerr << "Error creating socket" << std::endl;
        // Handle error
    }

    struct sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(serverPort);
    inet_pton(AF_INET, serverIP.c_str(), &serverAddr.sin_addr);

    setID(serverid);

    if (connect(clientSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == -1) {
        std::cerr << "Error connecting" << std::endl;
        // Handle error
    }
}


void serverClient::sendMessage(const std::string& message) {
    send(clientSocket, message.c_str(), message.size(), 0);
    // ...
    close(clientSocket);
}

void serverClient::setID(std::string& id)
{serverID = id;
}

std::string serverClient::getID()
{
    return serverID;
}
