#include "loadBalancer.h"
#include <iostream>
#include <cstring>
#include <arpa/inet.h>
#include <unistd.h>
#include <json/json.h>
#include <fstream>

loadBalancer::loadBalancer(int port) : port(port) {
    loadBalancerSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (loadBalancerSocket == -1) {
        std::cerr << "Error creating socket" << std::endl;
        // Handle error
    }

    struct sockaddr_in loadBalancerAddr;
    loadBalancerAddr.sin_family = AF_INET;
    loadBalancerAddr.sin_port = htons(port);
    loadBalancerAddr.sin_addr.s_addr = INADDR_ANY;
    printf("loadBalancer socket: %d\n",loadBalancerSocket);
    if (bind(loadBalancerSocket, (struct sockaddr*)&loadBalancerAddr, sizeof(loadBalancerAddr)) == -1) {
        std::cerr << "Error binding" << std::endl;
        // Handle error
    }
}

void loadBalancer::startListening() {
    if (listen(loadBalancerSocket, 5) == -1) {
        std::cerr << "Error listening" << std::endl;
        // Handle error
    }

    std::cout << "loadBalancer listening on port " << port << "..." << std::endl;

    while (true) {
        struct sockaddr_in clientAddr;
        socklen_t clientAddrSize = sizeof(clientAddr);
        int clientSocket = accept(loadBalancerSocket, (struct sockaddr*)&clientAddr, &clientAddrSize);
        if (clientSocket == -1) {
            std::cerr << "Error accepting connection" << std::endl;
            // Handle error
            //continue;
        }
        
        // Read data from client
        char buffer[256];
        memset(buffer, 0, sizeof(buffer));
        
        int bytesRead = recv(clientSocket, buffer, sizeof(buffer), 0);



    Json::Value json_object;
    Json::CharReaderBuilder reader;
    std::istringstream iss(buffer);
    std::string errs;

    // Parse the JSON string into a JSON object
    Json::parseFromStream(reader, iss, &json_object, &errs);

    json_object["message"] = json_object["message"].asString();
    
    std::ofstream outFile("middleman.json");  // Open the file for writing

    
    outFile << json_object;  // Write the modified JSON object to the file
    outFile.close();  // Close the file
    
        if (bytesRead <= 0) {
            std::cerr << "Error reading data" << std::endl;
            // Handle error
        } else {
            // std::cout << "Received data from client: " << buffer << std::endl;
            std::cout << "mesasge: " << json_object["message"].asString() << std::endl;
        }
        
        close(clientSocket);
    }

    

    close(loadBalancerSocket);
}

