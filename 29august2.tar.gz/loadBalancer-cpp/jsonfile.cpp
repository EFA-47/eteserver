#include "jsonfile.h"

std::string getJsonContent(std::string path){
    //get json content from message.json as a string
    std::ifstream in(path, std::ios::in | std::ios::binary);
    std::ostringstream contents;
    contents << in.rdbuf();
    in.close();
    return contents.str();
}

Json::Value getJsonObject(std::string jsonString)
{
    Json::Value json_object; 
    Json::CharReaderBuilder reader;
    std::istringstream iss(jsonString);
    std::string errs;
    Json::parseFromStream(reader, iss, &json_object, &errs);
    return json_object;
}

std::string getJsonValue(Json::Value json_object){
    //get json value from "json object" and append a string. transfer it to jsonString
    json_object["message"] = json_object["message"].asString();
    Json::StreamWriterBuilder writer;
    return Json::writeString(writer, json_object);
}
